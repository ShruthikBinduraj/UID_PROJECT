class calc{
    public static void main(String args[])
    {
        int a=5,b=-3,c=0;
        if(( a < b ) || ( c < b ) )
            System.out.println((( a < b ) || ( c < b ) ));
        else
            System.out.println("False");
        if(( c < a ) && ( c < b ) )
            System.out.println("True");
        else
            System.out.println("False");
        if(!( a + b > c ) )
            System.out.println("True");
        else
            System.out.println("False");

    }
}
